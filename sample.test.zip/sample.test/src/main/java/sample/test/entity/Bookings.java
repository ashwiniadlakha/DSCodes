package sample.test.entity;

import java.util.Date;

public class Bookings {

	String bookingId;
	String BookingStatus;
	Date createdTimestamp;
	Date updateTimestamp;
	
}
